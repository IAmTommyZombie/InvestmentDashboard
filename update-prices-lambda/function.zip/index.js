const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const {
  DynamoDBDocumentClient,
  ScanCommand,
  PutCommand,
} = require("@aws-sdk/lib-dynamodb");
const axios = require("axios");

const client = new DynamoDBClient({ region: "us-east-2" });
const docClient = DynamoDBDocumentClient.from(client);
const YAHOO_API_KEY = "YOUR_YAHOO_API_KEY"; // We'll add this as an environment variable

async function updatePrice(ticker) {
  try {
    const response = await axios.get(`https://yfapi.net/v6/finance/quote`, {
      params: { symbols: ticker },
      headers: { "x-api-key": YAHOO_API_KEY },
    });

    const price = response.data.quoteResponse.result[0].regularMarketPrice;

    await docClient.send(
      new PutCommand({
        TableName: "prices",
        Item: {
          ticker,
          currentPrice: price,
          lastUpdated: new Date().toISOString(),
          source: "yahoo",
        },
      })
    );

    console.log(`Updated price for ${ticker}: $${price}`);
    return price;
  } catch (error) {
    console.error(`Error updating price for ${ticker}:`, error);
    throw error;
  }
}

exports.handler = async (event) => {
  try {
    // Get all tickers from portfolios table
    const portfoliosResponse = await docClient.send(
      new ScanCommand({
        TableName: "portfolios",
        ProjectionExpression: "ticker",
      })
    );

    const tickers = portfoliosResponse.Items.map((item) => item.ticker);
    console.log("Tickers to update:", tickers);

    // Update each ticker's price
    const updates = await Promise.all(
      tickers.map((ticker) => updatePrice(ticker))
    );

    return {
      statusCode: 200,
      body: JSON.stringify({
        message: "Prices updated successfully",
        updatedTickers: tickers,
        updates,
      }),
    };
  } catch (error) {
    console.error("Error:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        message: "Error updating prices",
        error: error.message,
      }),
    };
  }
};
